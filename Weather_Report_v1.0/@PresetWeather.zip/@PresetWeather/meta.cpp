protocol = 1;
publishedid = 2844108808;
name = "PresetWeather";
timestamp = 5249643415806592531;
