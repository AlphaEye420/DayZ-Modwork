FYI: this is the data folder where you put both:
1. ALL of the loading still pics edds file(s)
2. Your loading screen music ogg file


MUSIC FILES ARE STICKY AT TIMES, 
FOLLOW THESE POCEEDURES TO ENSURE THE BEST POSSIBLE OUTCOME FOR MUSIC IN DAYZ:
1. Convert your audio to MP3 first, before converting to ogg (in step 6)
2. Right Click your file in Windows Explorer and nav to Details Tab
3. Click "Remove Properties and Personal Information"
4. Select "Remove the follwing properties from this file:"
5. Check EVERY POSSIBLE BOX if any removable text exists under Value and press ok to remove it (this removes ALL tags)
6. Drag file from folder into this website https://www.freeconvert.com/mp3-to-ogg and download the file
7. Name it to what you have in your mod's code

Tags are usually the issue with music not playing
Also converting wav to ogg file sometimes doesn't work and converting to ogg from mp3 works better
