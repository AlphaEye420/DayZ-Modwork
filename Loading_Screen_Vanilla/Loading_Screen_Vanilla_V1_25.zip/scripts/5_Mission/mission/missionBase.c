 modded class MissionBase
{
    override void InitialiseWorldData()
    {

        m_WorldData = new ChernarusPlusData();
        m_DynamicMusicPlayerRegistry = new DynamicMusicPlayerRegistryDeerisle();

    }
}