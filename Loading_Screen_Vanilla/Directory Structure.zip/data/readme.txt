FYI: this is the data folder where you put both:
1. ALL of the loading still pics edds file(s)
2. Your loading screen music ogg file
