# DayZ Map Plotter - BUTTON FUNCTIONS:
## **LOAD FILE, IMPORT COLOR/SIZE:**
* LOAD as many DAYZ FILES as you want. You can change the import color and size each time if you want
* You can also wait until you are done loading all files
* *SUPPORTED FORMATS* Importing and visualizing coordinate data from:
	* .json (AI Patrols, Fresh Spawns, Base Zones, Map Markers)
	* .xml (Territories, Event Spawns, Map Groups)
	* .c (Object Spawners)
	* .map (Traders, Misc Objects)

## **LEGEND USAGE:**
* LEFT CLICK Legend DOTS to change COLOR of all dots in the legend entry's group
* RIGHT CLICK Legend DOTS to change SIZE of all dots in the legend entry's group
* LEFT CLICK Legend NAMES to change the name
* RICHT CLICK Legend NAMES to delete the ENTIRE group of dots - *confirmation needed*

## **MAP DOT USAGE:**
* LEFT CLICK on a MAP DOT to copy the coordinates
* SHIFT-LEFT CLICK to change the name of an individual dot
* CONTROL-SHIFT-LEFT CLICK anywhere on the map to create a new dot
	* You can add them to existing legend groups or create a new one
	* Any created group takes on the default import color and size for dots
	* Dots adopt the formatting from an existing group if selected
* RIGHT CLICK on a dot to delete it - *confirmation needed*
* HOVER your mouse over a dot to see its information

## **PASTE COORDINATES FROM CLIPBOARD:**
* Using a text editor, copy any section of a file and hit the PASTE CLIPBOARD button
* Any detected coordinates will be applied to the map and get a legend group of its own

## **MAP ASSEMBLIES:**
* SAVE your collection of edited dots as a MAP ASSEMBLY for later recall using the SAVE/LOAD ASSEMBLY buttons
* You can add as many assemblies and files together as you want
* Best Practice: Load saved assemblies after setting the map & size to what was used at the time you saved the assembly

## **EXPORT to CLIPBOARD or FILE:**
* Click to chose the coordinate parsing format you wish to use
	* Exports to simple text or .csv, .xml, .map, .c, and .json formatted strings
	* It automatically copies to the clipboard so you can paste the coordinates into a text editor
* You can also save the copied coordinates as a file

## **MAP SETTINGS:**
* CHOOSE A MAP - built in maps or custom map
* When LOADING a CUSTOM MAP, be sure to properly set the size on the second pop-up dialog
	* Size should be the farthest northeast coordinate on the map, and the map must be square
	* Most image types are supported
* Select a radius size for the mouse hover circles that appear on the map dots

### **ERASE** all dots to start over

#### **HELP & ABOUT** files are stored as .md files in the app's main folder