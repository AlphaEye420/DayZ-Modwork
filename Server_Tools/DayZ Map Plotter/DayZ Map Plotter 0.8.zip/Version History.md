# **DayZ Map Plotter** - version 0.8 BETA
* Developed by AlphaEye (2025)
* Coordinates are extracted and displayed as points over a map background of your choosing.
* Supports DayZ 1.28 & Dayz Expansion Mod Files

## **VERSION HISTORY**

## v0.8 Change Notes
* ADDED User-sized semi-transparent circles to mouse hover on map dot
* UPDATED Map Settings Button to have built in maps + Hover Radius setting
* ADDED Map Support for Banov, Bitterroot, Chernarus, Chiemsee, Esseker, Livonia, Namalsk, and Sakhal
	* These maps are already sized
	* You may still choose a custom image and mapsize by selecting "Custom Map..."
* UPDATED MAP ASSEMBLIES to include stored map name and size parameters
	* Old assemblies will not load!  Save all new assemblies.
	* You can edit the old assemblies json formatting to match the provided Sample Assembly

## v0.7 Change Notes
* ADDED ability to CONTROL-SHIFT-LEFT MOUSE CLICK the map to create a dot - dialog appears
* ADDED ability to EXPORT all of the dots on the map to a specific format for pasting or saving into other files
* UPDATED Help and About BUTTONS to use Markdown pop-up files, plus added the new functions to the help file
* Updated the location of windows when they appear
* Added tool tips to hovering mouse over a button
* Included new Help.md File

## v0.6 Change Notes
* ADDED ability to Shift Left Click Dots to change their name
* ADDED ability to paste coordinates from the clipboard
* Updated Help file with the above functionality
* Forced Legend Entry Names to be Unique by adding numerics on detected duplicates upon creation
* Included new Version History.md file

## v0.5 Change Notes
* Added exception handlers to instances of loading corrupt files or incorrectly formatted assemblies - no more crashing the app
* Added Help Button
* Fixed the Legend Right Click name to delete group bug
* Fixed deleted dots returning to the map upon changing the color of the legend group
* Fixed error message on zooming maps with no dots on it yet
* Helped map not zooming to mouse cursor - still might miss a zoom on cursor, usually gets it on next mouse wheel or 2
* Updated zooming to be faster
* Fixed map sometimes changing the size of the dots when zooming 
	* Results in the dot sizes feeling 1 size bigger than v0.4
	* *(Dots were loading in too small then resizing to correct size on zoom)*
	* I left the smaller size on the dots in the legend to keep the legend more compact
* Fixed mouse cursor errantly set to dragging map after clicking ok in dialog box when copying a dot 's coordinates
* Set limits to dot sizes - 2 to 100 is the allowed range of size

## v0.4 Change Notes
* Added icon for taskbar when app is running
* Added Right Click Legend Name - to delete entire group from the map - w/ confirmation box 
* Added SIZE of map choice - allowing for any square map to be used
* Added Ability to remember last map image - Load-up of the app will load last used, if it doesn't exist it will revert to default
* Added support for MapGroupCluster.xml and MapGroupPos.xml files to be imported
* Added Name Tags to each dot, seen on mouse over and on the copy coordinate popup
* Updated copy to be like iZurvives "1000, 3333" only... no more "x:" or "z:"
* Updated Mouse Cursors so you know when over a dot or legend item - otherwise it is ready for the drag mechanic (cross cursor)

## v0.3 Change Notes
* Fixed right click dot eraser issues
* ADDED functions to the legend
	* Left Click dot to apply new color to dots associated with the legend entry
	* Right Click dot to apply new size to ^^
	* Left Click Legend Entry Name to change it - _good for comparing two files of the same name or segmenting one file by deleting some coords at a time before import_
* Added Tooltip on mouse-over of a dot showing its x, z
* Added background image change button
* Updated Button order and font sizes for more important buttons to stand out
* Updated About with more robust info
* Added a sample Map Assembly that matches my pic before I did some editing to test features - in samples dir
* Rewrote framework for storing dot variables to be more accepting of any future plans for them - this also fixed a lot of new bugs from creating the above legend functions

## v0.2 Change Notes
* Added Save/Load "Map Assembly" buttons - json that you store for later recall
* Added A legend - populates on load file or load assembly - draggable
* Can now left click dots to copy xz
* Can now right click dots to delete them - confirmation box
* The confirmation boxes were removed for color and size selection

## v0.1
* Requires: https://dotnet.microsoft.com/en-us/download/dotnet/8.0
* Simply loaded a file onto the map and made dots of chosen size and color
* Laid framework for advancements