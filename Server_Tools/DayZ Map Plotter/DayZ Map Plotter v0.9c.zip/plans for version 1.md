# Plans for v1.0
## 1. Better Dot Management & Filtering
* Highlighted Dot Framework
* Search Bar for Legend Groups or Dots: Type part of a group name or dot name to highlight or isolate them on the canvas
* Visibility Toggle checkbox next to each legend entry to show/hide dots (and their range rings) without deleting them
* Bulk Editing Tool to Select multiple dots via a drag-select box or a filter and edit attributes like size, color, group, etc.
## 2. Map Interaction Enhancements
* Mini-map or Overview Window: A small corner map/window showing where you are when zoomed in heavily or information
* Dynamic Scale Bar (100m/500m/etc.) that updates as you zoom in/out
## 3. Export & Integration Upgrades
* Custom Export Templates allowing users to define their own export format (drag-and-drop tokens for X, Y, Z, Name, etc.)
## 4. Performance & Workflow Tools
* Undo/Redo - Tracks dot additions, deletions, and moves for easy recovery
* Dot History Panel - Log of recently added or deleted dots with quick restore
* Session Autosave/Restore - Automatic backups the assembly every 5 minutes in case of a crash
## 5. Visualization Polish
* Arrow/Vector Support for “A” Values (Instead of just storing angles, render arrows for those dots)
* Radii Style Settings - Let users change how hover and range circles look (dotted, dashed, filled, or outline)
* Heat Map Mode - Option to visualize density of dots by coloring clusters (useful for quickly spotting hotspots)
## 6. Advanced Legend Tools
* Merge group into another group - prompt to change name/color/size
## 7. Quality of Life
*  Map Settings Button fitted with more configurable defaults (default colors, dot sizes, folders, etc.)
*  v1.0 Tutorial / Guided Use Video on YouTube
* Make the app fully portable (all data/settings stored locally, no registry)