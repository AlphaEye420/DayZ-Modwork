static void Place_Forge()
{
	SpawnObject( "FreezeGrindingStone_Static", "4502 8.14195 12034", "295.00000 0.000000 0.000000" );
	SpawnObject( "FreezeAnvil_Static", "4503 8.15866 12035", "128.00000 0.000000 0.000000" );
	SpawnObject( "FreezeFurnace_Static", "4504 8.05836 12037", "133.300000 0.000000 0.000000" );
	
	
	SpawnObject( "FreezeGrindingStone_Static", "1256 7.09241 13497", "195.00000 0.000000 0.000000" );
	SpawnObject( "FreezeAnvil_Static", "1255 7.10912 13496", "310.00000 0.000000 0.000000" );
	SpawnObject( "FreezeFurnace_Static", "1253 7.00883 13494", "30.0000 0.000000 0.000000" );
	
	
	SpawnObject( "FreezeGrindingStone_Static", "9058 34.5819 7608", "150.00000 0.000000 0.000000" );
	SpawnObject( "FreezeAnvil_Static", "9058, 34.5986 7609", "97.00000 0.000000 0.000000" );
	SpawnObject( "FreezeFurnace_Static", "9058 34.4983 7611", "93.00000 0.000000 0.000000" );
	
	
	SpawnObject( "FreezeGrindingStone_Static", "6817.13 42.4881 2459.07", "332.00000 0.000000 0.000000" );
	SpawnObject( "FreezeAnvil_Static", "6818 42.5048 2458.7", "149.00000 0.000000 0.000000" );
	SpawnObject( "FreezeFurnace_Static", "6819.5 42.4045 2459.25", "177.00000 0.000000 0.000000" );
	
	
	SpawnObject( "FreezeGrindingStone_Static", "2812.26 6.54684 6186.48", "15.6218 0.000000 0.000000" );
	SpawnObject( "FreezeAnvil_Static", "2813.8 6.56355 6189.31", "180.00000 0.000000 0.000000" );
	SpawnObject( "FreezeFurnace_Static", "2811.64 6.46325 6188.81", "111.300000 0.000000 0.000000" );
}