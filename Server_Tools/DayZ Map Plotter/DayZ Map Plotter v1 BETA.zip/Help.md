# DayZ Map Plotter
**Press F2 to pop up this image & close it**
![Mouse Usage Quick View](MapPlotterHelper.png)
## **LEGEND USAGE:**
* **LEFT CLICK** and hold the legend to drag it about the map
* **RIGHT CLICK** the legend window to toggle the arrows needed to reorder the legend entries
* *Tool tips appear on legend entries to show the total dots in the group*
#### **DOTS**
* **LEFT CLICK Legend DOTS** changes COLOR of all dots in the legend entry's group
* **RIGHT CLICK Legend DOTS** changes SIZE of all dots in the legend entry's group
#### **NAMES**
* **LEFT CLICK Legend NAMES** changes the group name
* **CONTROL + LEFT CLICK Legend NAMES** to EXPORT only the dots associated with the group
* **SHIFT + LEFT CLICK Legend NAMES** to MERGE the group into another group and take on its color and size
* **RIGHT CLICK Legend NAMES** to filter the map to only the dots of the group showing
	* *Press escape, or click the ReDraw button in upper right, or Right click a Legend Name or Dot to redraw all dots*
* **CONTROL + RIGHT CLICK Legend NAMES** to hide a group of dots from the map - repeat process to return them to the map
* **ALT + RIGHT CLICK Legend NAMES** to delete the ENTIRE group of dots - *confirmation needed*
## **MAP USAGE:**
* **Mouse Wheel** sets zoom
* **LEFT CLICK** and hold to drag the map
* **SHIFT + LEFT CLICK** anywhere on the map to create a new dot:
	* You can add them to existing legend groups or create a new one
	* Any created group takes on the default import color and size for dots
	* Dots adopt the formatting from an existing group if selected
* **CONTROL + LEFT CLICK** Drag a box and then edit the dots found within it (can mass change group, or mass delete)
#### **DOTS**
* **LEFT CLICK on a MAP DOT** to copy the coordinates
* **SHIFT + LEFT CLICK** changes the name of an individual dot
* **ALT + LEFT CLICK** changes a dot's X, Y, Z, A, or R values
* **RIGHT CLICK on a MAP DOT** to filter the map to only that dot's group members
	* *Press escape, or click the ReDraw button in upper right, or Right click a Legend Name or Dot to redraw all dots*
* **CONTROL + RIGHT CLICK** changes the legend group to which the dot belongs
* **ALT + RIGHT CLICK** on a dot to delete it - *confirmation needed*
* **HOVER** your mouse over a dot to see its information
- *Dots will hollow out if the name of the dot ends in "Trigger"*
# BUTTON FUNCTIONS
## **LOAD FILE:**
* LOAD as many DAYZ FILES as you want
* Asks you if you want to change color and size for each file
	* Yes - dialogues appear
	* No - uses last used settings - remembers even if app is closed
* Each file automatically makes a legend group entry of its own - you may select multiple files in the import dialog
* *SUPPORTED FORMATS* Importing and visualizing coordinate data from:
	* .json (Exp.AIPatrols, Exp.Spawns, Exp.Bases, Exp.Map, SpawnerBubaku)
	* .xml (Territories, Event Spawns, Map Groups)
	* .c (Map Modding, Custom Object Spawners)
	* .map (Exp.Traders, Exp.Objects)

## **PASTE COORDINATES FROM CLIPBOARD:**
* Using a text editor, copy any section of a file and hit the PASTE CLIPBOARD button *(Control V also pastes coordinates)*
* Any detected coordinates will be applied to the map and get a legend group of its own

## **MAP ASSEMBLIES:**
* SAVE your collection of edited dots as a MAP ASSEMBLY for later recall using the SAVE/LOAD ASSEMBLY buttons
* You can combine as many assemblies, imported files and pastes together as you want - Save as new assembly
* Best Practice: Load saved assemblies after setting the map & size to what was used at the time you saved the assembly

## **EXPORT to CLIPBOARD or FILE:**
* Click to chose the coordinate parsing format you wish to use
	* Exports to simple text or .csv, .xml, .map, .c, and .json, bubaku formatted strings
	* It automatically copies to the clipboard so you can paste the coordinates into a text editor
* You can also save the copied coordinates as a file

## **SETTINGS:**
* CHOOSE A MAP - built in maps or custom map
* When LOADING a CUSTOM MAP, be sure to properly set the size on the second pop-up dialog
	* Size should be the farthest northeast coordinate on the map, and the map must be square
	* Most image types are supported
* Select a radius size for the mouse hover circles that appear on the map dots - does NOT affect the dot's range circle
* Use the Sliders to adjust Hover and Rance Circle opacity and Heat Map size
* Range circles and Heat Map auto preview on the fly, but they don't take full effect until you select OK
* You may continue using the app with the settings window open

## **HEATMAP:**
* Blue-> Green-> Yellow-> Red Gradient (reddest square is the most populated square, transparency is also gradient)
* Use the HeatMap button at the top to toggle the heat map squares on and off
* Use the Settings button to adjust the size of the squares (auto adjusts relative to the size of the map)
* You may use the HeatMap button (and scroll the map) with settings window still open

#### **ERASE ALL** dots to start over

#### **CONTROL + Z = UNDO || CONTROL + Y = REDO** (when available)

#### **HELP (F1) & ABOUT (Shift+F1)** files are stored as .md files in the app's main folder

#### **ReDraw** button appears when the map dots are filtered - resets to show all