# DayZ Map Plotter

## **LEGEND USAGE:**
* **LEFT CLICK Legend DOTS** to change COLOR of all dots in the legend entry's group
* **RIGHT CLICK Legend DOTS** to change SIZE of all dots in the legend entry's group
* **LEFT CLICK Legend NAMES** to change the name
* **CONTROL-LEFT CLICK Legend NAMES** to EXPORT only the dots associated with the group
* **RICHT CLICK Legend NAMES** to delete the ENTIRE group of dots - *confirmation needed*

## **MAP DOT USAGE:**
* **LEFT CLICK** on a MAP DOT to copy the coordinates
* **SHIFT-LEFT CLICK** to change the name of an individual dot
* **ALT-LEFT CLICK** = change a dot's X, Y, Z, A, or R values
* **CONTROL-SHIFT-LEFT CLICK** anywhere on the map to create a new dot
	* You can add them to existing legend groups or create a new one
	* Any created group takes on the default import color and size for dots
	* Dots adopt the formatting from an existing group if selected
* **RIGHT CLICK** on a dot to delete it - *confirmation needed*
* **ALT-RIGHT CLICK** = change the legend group to which the dot belongs
* **HOVER** your mouse over a dot to see its information
* *Dots will hollow out if the name of the dot ends in "Trigger"*

# BUTTON FUNCTIONS
## **LOAD FILE:**
* LOAD as many DAYZ FILES as you want
* Asks you if you want to change color and size for each file
	* Yes - dialogues appear
	* No - uses last used settings - remembers even if app is closed
* Each file automatically makes a legend group entry of its own - you may select multiple files in the import dialog
* *SUPPORTED FORMATS* Importing and visualizing coordinate data from:
	* .json (AI Patrols, Fresh Spawns, Base Zones, Map Markers, SpawnerBubaku)
	* .xml (Territories, Event Spawns, Map Groups)
	* .c (Object Spawners)
	* .map (Traders, Misc Objects)

## **PASTE COORDINATES FROM CLIPBOARD:**
* Using a text editor, copy any section of a file and hit the PASTE CLIPBOARD button
* Any detected coordinates will be applied to the map and get a legend group of its own

## **MAP ASSEMBLIES:**
* SAVE your collection of edited dots as a MAP ASSEMBLY for later recall using the SAVE/LOAD ASSEMBLY buttons
* You can combine as many assemblies, imported files and pastes together as you want - Save as new assembly
* Best Practice: Load saved assemblies after setting the map & size to what was used at the time you saved the assembly

## **EXPORT to CLIPBOARD or FILE:**
* Click to chose the coordinate parsing format you wish to use
	* Exports to simple text or .csv, .xml, .map, .c, and .json, bubaku formatted strings
	* It automatically copies to the clipboard so you can paste the coordinates into a text editor
* You can also save the copied coordinates as a file

## **MAP SETTINGS:**
* CHOOSE A MAP - built in maps or custom map
* When LOADING a CUSTOM MAP, be sure to properly set the size on the second pop-up dialog
	* Size should be the farthest northeast coordinate on the map, and the map must be square
	* Most image types are supported
* Select a radius size for the mouse hover circles that appear on the map dots - does NOT affect the dot's range circle

### **ERASE** all dots to start over

#### **HELP & ABOUT** files are stored as .md files in the app's main folder