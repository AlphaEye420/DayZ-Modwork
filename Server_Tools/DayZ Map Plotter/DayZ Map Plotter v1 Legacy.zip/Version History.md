# **DayZ Map Plotter** - version 1.00 BETA
> **Developed by AlphaEye** ©2025  
> Coordinates are extracted and displayed as points over a map background of your choosing  
> You can then edit, organize, analyze and/or export your 'map assembly'  
> *Supports DayZ 1.28 & DayZ Expansion Mod Files*

# **VERSION HISTORY**
## **v1.00** Change Notes
* **ADDED Simple undo/redo** - Control+Z to UNDO - Control-Y to REDO *(only goes back one move)*
* **ADDED FILTER MODE** - When filtered, press escape, or right click the object again, or press the "Redraw" button to return all dots
* **CHANGED/ADDED Legend Names' Right Click features:** 
	* Alt key now required to delete a Legend Group when right clicking the group name
	* Control-Right Click Name to hide the group, you can hide multiple groups *(analogous to 'mute' button on sound mixers)*
	* Regular Right Click now filters the map to show only the groups' dots *(analogous to 'solo' mode on sound mixers)*
* **CHANGED MAP DOT RIGHT CLICK** 
	* Right Click to filter map to group *(same way as right clicking the legend group name)*
	* Control-Right-Click to change a dot's group
	* Alt-Right-Click to Delete a Dot
* **ADDED Hold and Drag with Control-Left Click** - dialog to edit group or delete found dots
* **ADDED Shift+Left Mouse click on a Legend Name** - will bring up a **"Merge to Group"** dialog to merge into another group
* **ADDED Ability to move legend groups up and down the list** - Right Click the Legend Window itself to toggle arrows
* **ADDED Total Dot Count** to the tooltip when hovering at the top of the legend
* **CHANGED Shift-Click to add map dot** - no longer need control down as well
* **ADDED Arrow/Vector Support for “A” Values** (renders lines if A is not zero)
* **ADDED Help Image** for quick view of mouse use
* **ADDED Control V support for Paste Button
* **ADDED F1, Shift+F1, F2** key use - F1 is same as Help button, Shift+F1 About button, F2 shows a pop-up of the image at the top of Help
* **ADDED HEAT MAP FEATURE** - toggle on and off at the top of the app - use settings button to adjust
* **UPDATED Settings button** to allow use of the map - *(also has the heat map adjustments)*
* **ADDED Settings CheckBox** to toggle the loading of the last assembly on restart *(closing with empty map negates this feature)*
* **ADDED Radii Style Settings** - change how hover and range circles look (dotted, dashed, or outline: with fill or not)
* **ADDED SEARCH Feature** where you can edit the found dots individual - select multiple dots - centers on dot - change group or delete
* **UPDATED App to recognize crashes**, which will allow it to restore the last known session assembly
* **UPDATED Escape Key** feature to close pop-up boxes: Paste / Export / Settings / Help / Help Image (F2) / About
* FIXED Sliders in Settings Window always defaulting to 40% when opening the window - will match current settings now
* FIXED Radius Circle not deleting along with dot on Alt-Right Click of a map dot
## **v0.9** Change Notes
* Cleaned code redundancies via help of AI bot
* Uses 25% less memory and will not leak memory
* Can paste multiple events now
* Tooltip on Legend has the count of points in each group
* Fixed map scaling for all maps when switching between them
* **ADDED Support for SpawnerBubaku files** to be imported using Load or Paste - can also Export the style to .txt
* UPDATED dots to hollow out when the name of the dot ends in "Trigger" - *(sb helpful)*
* **ADDED Support for Range, Angle and Y values** to be stored with the dots
	* Auto detects on Loaded File or Pasted values *(also stored in assemblies)*
	* Group, Name, X, Y, Z, A, R will all then transfer to any export you make *(as necessary per type of export)*
* **ADDED Ability to hold Control when Left Clicking a legend name to Export *ONLY* its dots**
* **ADDED Ability to hold Alt when Left or Right Clicking a map dot**
	* ALT-LEFT CLICK = change dot X, Y, Z, A, or R
	* ALT-RIGHT CLICK = change the legend group to which the dot belongs
* **ADDED constant colored circles attached to the new Range value**
	* A 2nd circle still happens on mouse hover as well
	* UPDATED Map Settings Button to include Opacity Sliders for the Hover & Range Circles - remembers last setting
* **UPDATED the "Paste Clipboard" button:**
	* Includes as much of the Name, X, Y, Z, A, R as it can detect and attach it to the dots
	* Successful import notification now states style of coordinates that it detected
	* ADDED UI to append to an existing legend entry Group *(uses group color/size)*, or create a new entry *(asks for color/size)*
* **UPDATED all Imports to ask for color and size changes** *(Yes/No replaces the "OK" button)*
	* Selecting No uses last used color and size
	* If no prior usage is detected or if the settings.json file is corrupt, it will default back to Red/8
	* REMOVED Import Color and Import Size Buttons
	* App will always remember last used for default even if closed and re-opened
* FIXED bug on loading file then zooming causing an error message
* FIXED bug on deleting a legend group then zooming ^same message
* ADDED Support for legacy assemblies, so you can load any old assembly - *best practice to then re-save the assembly*
* ADDED Support for legacy settings, in case you are missing or have an old version of the settings.json it will auto update

## **v0.8** Change Notes
* **ADDED User-sized semi-transparent circles to mouse hover** on map dot
* **UPDATED Map Settings Button to have built in maps + Hover Radius setting**
* **ADDED Map Support** for Banov, Bitterroot, Chernarus, Chiemsee, Esseker, Livonia, Namalsk, and Sakhal
	* These maps are already sized
	* You may still choose a custom image and map-size by selecting "Custom Map..."
* **UPDATED MAP ASSEMBLIES** to include stored map name and size parameters
	* Old assemblies will not load!  Save all new assemblies.
	* You can edit the old assemblies json formatting to match the provided Sample Assembly

## **v0.7** Change Notes
* **ADDED ability to CONTROL-SHIFT-LEFT MOUSE CLICK the map to create a dot** - dialog appears
* **ADDED ability to EXPORT all of the dots on the map to a specific format** for pasting or saving into other files
* **UPDATED Help and About BUTTONS to use Markdown pop-up files**, plus added the new functions to the help file
* Updated the location of windows when they appear
* Added tool tips to hovering mouse over a button
* Included new Help.md File

## **v0.6** Change Notes
* **ADDED ability to Shift Left Click Dots** to change their name
* **ADDED ability to paste coordinates from the clipboard**
* Updated Help file with the above functionality
* Forced Legend Entry Names to be Unique by adding numerics on detected duplicates upon creation
* Included new Version History.md file

## v0.5 Change Notes
* Added exception handlers to instances of loading corrupt files or incorrectly formatted assemblies - no more crashing the app
* **Added Help Button**
* Fixed the Legend Right Click name to delete group bug
* Fixed deleted dots returning to the map upon changing the color of the legend group
* Fixed error message on zooming maps with no dots on it yet
* Helped map not zooming to mouse cursor - still might miss a zoom on cursor, usually gets it on next mouse wheel or 2
* Updated zooming to be faster
* Fixed map sometimes changing the size of the dots when zooming 
	* Results in the dot sizes feeling 1 size bigger than v0.4
	* *(Dots were loading in too small then resizing to correct size on zoom)*
	* I left the smaller size on the dots in the legend to keep the legend more compact
* Fixed mouse cursor errantly set to dragging map after clicking ok in dialog box when copying a dot 's coordinates
* Set limits to dot sizes - 2 to 100 is the allowed range of size

## **v0.4** Change Notes
* Added icon for taskbar when app is running
* **Added Right Click Legend Name** - to delete entire group from the map - w/ confirmation box 
* **Added SIZE of map choice** - allowing for any square map to be used
* **Added Ability to remember last map image** - Load-up of the app will load last used, if it doesn't exist it will revert to default
* **Added support for MapGroupCluster.xml and MapGroupPos.xml** files to be imported
* Added Name Tags to each dot, seen on mouse over and on the copy coordinate pop-up
* Updated copy to be like iZurvives "1000, 3333" only... no more "x:" or "z:"
* Updated Mouse Cursors so you know when over a dot or legend item - otherwise it is ready for the drag mechanic (cross cursor)

## **v0.3** Change Notes
* Fixed right click dot eraser issues
* **ADDED functions to the legend**
	* Left Click dot to apply new color to dots associated with the legend entry
	* Right Click dot to apply new size to ^^
	* Left Click Legend Entry Name to change it - _good for comparing two files of the same name or segmenting one file by deleting some coordinates at a time before import_
* **Added Tooltip on mouse-over** of a dot showing its x, z
* **Added background image change button**
* Updated Button order and font sizes for more important buttons to stand out
* Updated About with more robust info
* Rewrote framework for storing dot variables to be more accepting of any future plans for them - this also fixed a lot of new bugs from creating the above legend functions

## **v0.2** Change Notes
* **Added Save/Load "Map Assembly" buttons** - json that you store for later recall
* **Added A legend** - populates on load file or load assembly - drag-able
* **Added ability to left click dots** to copy xz
* **Added ability to right click dots** to delete them - confirmation box
* The confirmation boxes were removed for color and size selection

## **v0.1**
* **Requires: https://dotnet.microsoft.com/en-us/download/dotnet/8.0**
* Simply loaded a file onto the map and made dots of chosen size and color
* Laid framework for advancements