# DAYZ EXPANSION MARKET TRADERZONES RESTOCK APP

**A Safe & Simple Restocking Tool for DayZ Expansion Market** _~ A Simple Console App by Alpha Eye_  

---
### 📦 About This Tool

--> The **DAYZ EXPANSION MARKET TRADERZONES RESTOCK APP** offers a safe, fast, and automated way to manage your Traderzones inventories for DayZ servers running Expansion Market.  Forget the hassle of opening and editing JSON files manually. This tool handles the heavy lifting while keeping your server files safe by working offline, and it keeps logs to monitor its restocking progress.  Once you are confident in using the tool safely, you may never open a Traderzones file again!

### ⚙️ Key Features  
* **Lightweight** C# console application designed to **restock your DayZ Expansion Market Traderzones** JSON files  
* Adjusts stock levels for items based on thresholds and **applies chance-based logic** to decide whether or not items are restocked  
* **Simple Folder Structure**  
* Offline Restocking (**Safe for Servers**)  
* **Settings** for Total User Control of Inventories
* Includs a **Full Traderzones Folder Reset Tool** with Backup Created
* Full **Logging** of Actions with Statistics & Debugging
* Fast, Efficient, and **Reliable**  
* Open Source & **Free** (Private Use Only)

---
**⚠️ READ BEFORE YOU USE THIS TOOL!**  
* **Always back up your server files before applying changes**
* **This tool is designed to prevent direct modification of your live server files**
* **You are responsible for syncing updated files to your server manually**  
* This approach ensures safe operations and gives you the opportunity to review files before they go live
---

## 🚀 Quick Start Guide  
1. **Backup your files!** - _(3rd copy)_
2. **Copy your server "Traderzones" files into the provided "Traderzones" folder** - Best done near a coming server restart
3. **Edit _"thresholds.json"_ and _"chances.json"_** located in the "USER" folder
4. **Run _"Restock_Market.exe"** with the up-to-date copies in "Traderzones" folder
5. **Quickly review the logs in "USER/Restock.log"** - _(you can change how the log works, see Setup Instructions for how to do so)_
6. **Manually copy/sync your updated "Traderzones" folder back to your server at your own risk!** - best done directly before a server restart

---
## 🔧 Setup Instructions
* Place the unzipped program folder anywhere EXCEPT your live DayZ server folder 
* _Best practice: Keep a dedicated working folder for inventory editing_
* **Needed Json Files:** 
	* _The app most likely will not restock anything if there is an error in your json file(s)_
	* **/USER/thresholds.json** → Defines the threshold for each item - Restocks to this amount when current stock is found to be below
	  ```
	  {
		  "ItemName1": 20,
		  "ItemName2": 5
	  }
		  // 0 = Don't stock this 
		  // Don't set above your Market json files' maximum!
	  ```
	* **/USER/chances.json** → Defines the % chance an item will be restocked (1-100 integers) - An item not listed defaults to 100% chance
	  ```
	  {
		  "ItemName1": 50,
		  "ItemName2": 80 
	  }
		  // Value = 0 or less will never 
		  // Value = 100 or more will always 
	  ```
	* **/USER/settings.json** → Sets style for the pop-up console & /USER/Restock.log style - _If missing or error in file, it may default to below_
	  ```
	  {
		"Console_Logging": 1,
		"Restock_File_Logging": 2,
		"Restock_Random_Amount": 0
	  }
		  // ConsoleView: 1 = Normal | 0 = Condensed | -1 = Create Debug.Log
		  // Restock.log: 3 = Deep | 2 = Normal | 1 = Condensed | 0 = No Log Used | /USER/Restock.log will self-create if needed
		  // RandomRestock: 1 = Random % of needed stock to meet thresholds.json value | 0 = Restocks to thresholds.json value
		  // Set all three to -1 to enter Inventory Reset Mode
	  ```
* Inside the **/Traderzones folder: Place all Traderzone JSON files** you wish to update - **App will Overwrite these /Traderzones files!**
* Logs are created in /USER/Restock.log showing the restocking actions
* Change how the app restocks and logs its work with settings.json
____
### 📂 Folder Structure
```
Restock_Market\
├── Restock_Market.exe & its needed accompanying files
├── README.md (this file)
├── NPP_Log_Language_Coloring.xml (import to Notepad++ Languages section for best look for the /USER/Restock.log)
├── Traderzones\
│   └── (Your trader JSON files here)
├── USER\
│   ├── thresholds.json
│   ├── chances.json
│   ├── settings.json
│   ├── Restock.log (app will create on first use by itself)
│   └── Debug.log (app will create on first use by itself)
└── Backup_timestamp\
    └── (Your backup trader JSON files made when in Inventory Reset Mode)
```
____
## ▶️ How To Use to Restock Traderzones
* Run Restock_Market.exe - Follow Prompts if any
* It will check that /USER and /Traderzones exist
* It loads thresholds.json and chances.json from /USER
* It loops through each Traderzone file, checking the stock of each item  
**Restocking logic:**
	* If an item in the thresholds.json exists, it is checked to see if it exists in each Traderzones file
	* If the item's current stock is below the threshold, a dice roll (1-100) occurs
	  * If the dice roll is less than or equal to the chances.json value → item is restocked
	  * If the item isn't listed in chances.json → it’s always passes this roll
	  * If Random Restock Amount = 1, only a random fraction of needed stock is restocked, otherwise stocked to threshold amount
	* It moves on through every item in every file VERY quickly and logs progress
* Changes, if made, are saved and overwrite the files inside /Traderzones.
* A log of what happened is saved to /USER/Restock.log - set the style of the console and log with /USER/settings.json _(see Setup Instructions above)_
* The app waits for you to press a button to close the console - Then, you can check the newly overwritten Traderzones for accuracy
* If you set Console Logging to -1 you can debug the process using \USER\Debug.log
### ▶️ How To Use to RESET Traderzones Inventories for Re-intialising on Restart
* In the /USER/settings.json, set all three settings to -1
* When you start the program it will tell you it is in INVENTORY RESET MODE
* It will tell you where the Backups of your current Traderzones will be stored
* When you click 'Y' to continue, your /Traderzones folder files will all be reset to empty  [`"Stock"{}`]
* **_Be sure to return your settings.json back to normal settings when you are done!_**

____
## ▶️ Good Strategy / Things to Consider
* Set your thresholds to init or max values and your chances below 15% for everything except essentials, Random Amount = 1
* Set your thresholds to just enough 3-5 max, set your chances %20-50 except essentials %50-100, Random Amount = 0
* In general if you use Random Amount = 1 in /USER/settings.json, then you should keep thresholds higher
* Individually decide what you don't want players to find missing at the trader, and leave all else out of json files
* to stock different lists, make .json setups saved under differnent names and change the name is thresholds.json when needed
* The app is fast and crude enough to handle whatever you want to try, thousands of Items at hundreds of Traderzones if you wish
* When it is time to wipe your server, use the Inventory Reset Mode to reset your market, takes only seconds with even the largest markets
#### 🧠 Best Practices
* Do NOT run this app on your live server folder!
* Use the provided Traderzones folder for all edits and updates
* After running the app, review files and logs before uploading to the live server
* FTP or drag/drop your updated files into the server folder
* Works best for offline editing workflows & uploading near a server restart
#### 🔒 Why Is This Safer?
* No direct server file editing - You manually move updated files to your server
* Encourages backups and review - You are required to sync files yourself, ensuring time for QA
* User-controlled thresholds and chances - You decide the restock conditions by editing simple JSON files
* Change them at any time to help balance your inventories for the moment
#### ⚠️ Legal & Disclaimer
* Free to use for private use only
* Open Source — use at your own risk
* We take no responsibility for file loss, server issues, or bad uploads
* Always backup your files before you run Restock_Market.exe
* Review before upload! - By using this app, you acknowledge full responsibility for its use
#### 🛠️ Requirements
* Designed for Windows 10+ (.NET 8)
* Expansion Market Traderzones JSON files already setup for your server's traders
* The provided USER json files _(settings, thresholds & chances)_
#### 👨‍💻 Credits
* Created by: Alpha Eye - [Github](https://github.com/AlphaEye420/DayZ-Modwork/tree/main)  - Powered by: ChatGPT  
* Got questions? Found a bug? Join the Discord - [Alpha Eye's Discord](https://discord.gg/BdkSUQENhM)
* You can donate to Alpha Eye's cause, see the donations page in the upper left of discord
#### 🔖 Version Info
* DayZ v1.27
* Expansion v1.9.20
* Restock_Market App v1.0
