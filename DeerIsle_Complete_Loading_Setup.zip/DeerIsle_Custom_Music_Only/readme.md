## CUSTOM MENU MUSIC for DAYZ - works on Deer Isle
* CONFIG.CPP : you need to change the names of "YourPBOName" and your ogg file (add more shaders and matching soundsets if you wish)
* DATA FOLDER : your ogg files go here
* SCRIPTS/3_Game folder contains the call for your music
	* DynamicMusicPlayerRegistry.c : you need to change the name(s) of "YourPBOName"
	* Please read all comments in file!
* SCRIPTS/5_Missions - nothing to do, leave it be