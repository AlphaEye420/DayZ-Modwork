## Custom Main Menu Layouts for DayZ - works with Deer Isle
**Change "YourPBOName" where ever you see it in all files**
### Files included and what to do with them:
* config.cpp - name changes needed
* scripts/5_mission  has 2 files and 1 folder
  * InGameMenu.c - 1 name change
  * MainMenu.c - look for the comments several items need to be changed in the file!
  * GUI folder has the 2 layouts and image sets folder for icons
    * Feel free to use the icons provided in image sets - High Quality - or make your own
	* main menu.layout - change 1 name
	* day_z_ingamemenu.layout - change 1 name - match your logo size (keep lower than 600 pixel width)